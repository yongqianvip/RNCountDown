/*
* @author:  yinyongqian
* @createTime:  2017-07-25, 14:37:03 GMT+0800
* @description:  simple sms code count down button
*/
import CountDownButton from './CountDownButton'

export default CountDownButton